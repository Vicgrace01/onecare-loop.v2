"""OneCare Loop application package."""
